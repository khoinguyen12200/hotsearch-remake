module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/api/hotsearch/group/[apidate]/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./pages/api/ApiConst/connection.js":
/*!******************************************!*\
  !*** ./pages/api/ApiConst/connection.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var query = __webpack_require__(/*! ../../../server_config/connection */ "./server_config/connection.js");

/* harmony default export */ __webpack_exports__["default"] = (query); // var mysql = require("mysql");
// var pool = mysql.createPool({
// 	connectionLimit: 50,
// 	host: "localhost",
// 	user: "root",
// 	password: "",
// 	database: "hsdb",
// });
// export default function(sql, arr) {
// 	return new Promise((resolve, reject) => {
// 		pool.getConnection((err,connection) => {
// 			if(err) return reject(err);
// 			connection.query(sql, arr, function (err, results) {
// 				connection.release();
// 				if (err) return reject(err);
// 				else return resolve(results);
// 			});
// 		})
// 	});
// }

/***/ }),

/***/ "./pages/api/hotsearch/group/[apidate]/index.js":
/*!******************************************************!*\
  !*** ./pages/api/hotsearch/group/[apidate]/index.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ApiConst_connection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../ApiConst/connection */ "./pages/api/ApiConst/connection.js");

/* harmony default export */ __webpack_exports__["default"] = (async function (req, res) {
  const {
    apidate
  } = req.query;
  let results = await Object(_ApiConst_connection__WEBPACK_IMPORTED_MODULE_0__["default"])("SELECT * FROM `hot-search` WHERE date(date) = date(?)", [apidate]);

  for (let i in results) {
    const row = results[i];
    const articles = await Object(_ApiConst_connection__WEBPACK_IMPORTED_MODULE_0__["default"])("SELECT * FROM `hs-articles` WHERE idhotsearch = ?", [row.id]);
    results[i].articles = articles;
  }

  res.status(200).json({
    data: results
  });
});

/***/ }),

/***/ "./server_config/connection.js":
/*!*************************************!*\
  !*** ./server_config/connection.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var mysql = __webpack_require__(/*! mysql */ "mysql"); // var pool = mysql.createPool({
// 	connectionLimit: 10,
// 	host: "localhost",
// 	user: "root",
// 	password: "",
// 	database: "hsdb",
// });


var pool = mysql.createPool({
  connectionLimit: 10,
  host: "localhost",
  user: "kbpqveyq_khoi",
  password: "kbpqveyq_khoi2000",
  database: "kbpqveyq_hsdb"
});

module.exports = function (sql, arr) {
  return new Promise((resolve, reject) => {
    pool.getConnection((err, connection) => {
      if (err) return reject(err);
      connection.query(sql, arr, function (err, results) {
        connection.release();
        if (err) return reject(err);else return resolve(results);
      });
    });
  });
};

/***/ }),

/***/ "mysql":
/*!************************!*\
  !*** external "mysql" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("mysql");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vcGFnZXMvYXBpL0FwaUNvbnN0L2Nvbm5lY3Rpb24uanMiLCJ3ZWJwYWNrOi8vLy4vcGFnZXMvYXBpL2hvdHNlYXJjaC9ncm91cC9bYXBpZGF0ZV0vaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc2VydmVyX2NvbmZpZy9jb25uZWN0aW9uLmpzIiwid2VicGFjazovLy9leHRlcm5hbCBcIm15c3FsXCIiXSwibmFtZXMiOlsicXVlcnkiLCJyZXF1aXJlIiwicmVxIiwicmVzIiwiYXBpZGF0ZSIsInJlc3VsdHMiLCJpIiwicm93IiwiYXJ0aWNsZXMiLCJpZCIsInN0YXR1cyIsImpzb24iLCJkYXRhIiwibXlzcWwiLCJwb29sIiwiY3JlYXRlUG9vbCIsImNvbm5lY3Rpb25MaW1pdCIsImhvc3QiLCJ1c2VyIiwicGFzc3dvcmQiLCJkYXRhYmFzZSIsIm1vZHVsZSIsImV4cG9ydHMiLCJzcWwiLCJhcnIiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsImdldENvbm5lY3Rpb24iLCJlcnIiLCJjb25uZWN0aW9uIiwicmVsZWFzZSJdLCJtYXBwaW5ncyI6Ijs7UUFBQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLElBQUk7UUFDSjtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7O1FBR0E7UUFDQTs7Ozs7Ozs7Ozs7OztBQ3hGQTtBQUFBLElBQUlBLEtBQUssR0FBR0MsbUJBQU8sQ0FBQyx3RUFBRCxDQUFuQjs7QUFDZUQsb0VBQWYsRSxDQUVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0EsSTs7Ozs7Ozs7Ozs7O0FDekJBO0FBQUE7QUFBQTtBQUdlLCtFQUFnQkUsR0FBaEIsRUFBcUJDLEdBQXJCLEVBQTBCO0FBQ3JDLFFBQU07QUFBQ0M7QUFBRCxNQUFZRixHQUFHLENBQUNGLEtBQXRCO0FBRUEsTUFBSUssT0FBTyxHQUFHLE1BQU1MLG9FQUFLLENBQUMsdURBQUQsRUFBeUQsQ0FBQ0ksT0FBRCxDQUF6RCxDQUF6Qjs7QUFDQSxPQUFJLElBQUlFLENBQVIsSUFBYUQsT0FBYixFQUFzQjtBQUNsQixVQUFNRSxHQUFHLEdBQUdGLE9BQU8sQ0FBQ0MsQ0FBRCxDQUFuQjtBQUNBLFVBQU1FLFFBQVEsR0FBRyxNQUFNUixvRUFBSyxDQUFDLG1EQUFELEVBQXFELENBQUNPLEdBQUcsQ0FBQ0UsRUFBTCxDQUFyRCxDQUE1QjtBQUNBSixXQUFPLENBQUNDLENBQUQsQ0FBUCxDQUFXRSxRQUFYLEdBQXNCQSxRQUF0QjtBQUNIOztBQUNETCxLQUFHLENBQUNPLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUFDQyxRQUFJLEVBQUNQO0FBQU4sR0FBckI7QUFFSCxDOzs7Ozs7Ozs7OztBQ2RELElBQUlRLEtBQUssR0FBR1osbUJBQU8sQ0FBQyxvQkFBRCxDQUFuQixDLENBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLElBQUlhLElBQUksR0FBR0QsS0FBSyxDQUFDRSxVQUFOLENBQWlCO0FBQzNCQyxpQkFBZSxFQUFFLEVBRFU7QUFFM0JDLE1BQUksRUFBRSxXQUZxQjtBQUczQkMsTUFBSSxFQUFFLGVBSHFCO0FBSTNCQyxVQUFRLEVBQUUsbUJBSmlCO0FBSzNCQyxVQUFRLEVBQUU7QUFMaUIsQ0FBakIsQ0FBWDs7QUFTQUMsTUFBTSxDQUFDQyxPQUFQLEdBQWlCLFVBQVNDLEdBQVQsRUFBY0MsR0FBZCxFQUFtQjtBQUNuQyxTQUFPLElBQUlDLE9BQUosQ0FBWSxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDdkNiLFFBQUksQ0FBQ2MsYUFBTCxDQUFtQixDQUFDQyxHQUFELEVBQUtDLFVBQUwsS0FBb0I7QUFDdEMsVUFBR0QsR0FBSCxFQUFRLE9BQU9GLE1BQU0sQ0FBQ0UsR0FBRCxDQUFiO0FBQ1JDLGdCQUFVLENBQUM5QixLQUFYLENBQWlCdUIsR0FBakIsRUFBc0JDLEdBQXRCLEVBQTJCLFVBQVVLLEdBQVYsRUFBZXhCLE9BQWYsRUFBd0I7QUFDbER5QixrQkFBVSxDQUFDQyxPQUFYO0FBQ0EsWUFBSUYsR0FBSixFQUFTLE9BQU9GLE1BQU0sQ0FBQ0UsR0FBRCxDQUFiLENBQVQsS0FDSyxPQUFPSCxPQUFPLENBQUNyQixPQUFELENBQWQ7QUFDTCxPQUpEO0FBS0EsS0FQRDtBQVNBLEdBVk0sQ0FBUDtBQVdBLENBWkQsQzs7Ozs7Ozs7Ozs7QUNsQkEsa0MiLCJmaWxlIjoicGFnZXMvYXBpL2hvdHNlYXJjaC9ncm91cC9bYXBpZGF0ZV0uanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHJlcXVpcmUoJy4uLy4uLy4uLy4uL3Nzci1tb2R1bGUtY2FjaGUuanMnKTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0dmFyIHRocmV3ID0gdHJ1ZTtcbiBcdFx0dHJ5IHtcbiBcdFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcbiBcdFx0XHR0aHJldyA9IGZhbHNlO1xuIFx0XHR9IGZpbmFsbHkge1xuIFx0XHRcdGlmKHRocmV3KSBkZWxldGUgaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF07XG4gXHRcdH1cblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3BhZ2VzL2FwaS9ob3RzZWFyY2gvZ3JvdXAvW2FwaWRhdGVdL2luZGV4LmpzXCIpO1xuIiwidmFyIHF1ZXJ5ID0gcmVxdWlyZShcIi4uLy4uLy4uL3NlcnZlcl9jb25maWcvY29ubmVjdGlvblwiKTtcclxuZXhwb3J0IGRlZmF1bHQgcXVlcnk7XHJcblxyXG4vLyB2YXIgbXlzcWwgPSByZXF1aXJlKFwibXlzcWxcIik7XHJcblxyXG4vLyB2YXIgcG9vbCA9IG15c3FsLmNyZWF0ZVBvb2woe1xyXG4vLyBcdGNvbm5lY3Rpb25MaW1pdDogNTAsXHJcbi8vIFx0aG9zdDogXCJsb2NhbGhvc3RcIixcclxuLy8gXHR1c2VyOiBcInJvb3RcIixcclxuLy8gXHRwYXNzd29yZDogXCJcIixcclxuLy8gXHRkYXRhYmFzZTogXCJoc2RiXCIsXHJcbi8vIH0pO1xyXG5cclxuLy8gZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24oc3FsLCBhcnIpIHtcclxuLy8gXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4vLyBcdFx0cG9vbC5nZXRDb25uZWN0aW9uKChlcnIsY29ubmVjdGlvbikgPT4ge1xyXG4vLyBcdFx0XHRpZihlcnIpIHJldHVybiByZWplY3QoZXJyKTtcclxuLy8gXHRcdFx0Y29ubmVjdGlvbi5xdWVyeShzcWwsIGFyciwgZnVuY3Rpb24gKGVyciwgcmVzdWx0cykge1xyXG4vLyBcdFx0XHRcdGNvbm5lY3Rpb24ucmVsZWFzZSgpO1xyXG4vLyBcdFx0XHRcdGlmIChlcnIpIHJldHVybiByZWplY3QoZXJyKTtcclxuLy8gXHRcdFx0XHRlbHNlIHJldHVybiByZXNvbHZlKHJlc3VsdHMpO1xyXG4vLyBcdFx0XHR9KTtcclxuLy8gXHRcdH0pXHJcblx0XHRcclxuLy8gXHR9KTtcclxuLy8gfSIsImltcG9ydCBxdWVyeSBmcm9tICcuLi8uLi8uLi9BcGlDb25zdC9jb25uZWN0aW9uJztcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiAocmVxLCByZXMpIHtcclxuICAgIGNvbnN0IHthcGlkYXRlfSA9IHJlcS5xdWVyeTtcclxuICAgIFxyXG4gICAgbGV0IHJlc3VsdHMgPSBhd2FpdCBxdWVyeShcIlNFTEVDVCAqIEZST00gYGhvdC1zZWFyY2hgIFdIRVJFIGRhdGUoZGF0ZSkgPSBkYXRlKD8pXCIsW2FwaWRhdGVdKTtcclxuICAgIGZvcihsZXQgaSBpbiByZXN1bHRzKSB7XHJcbiAgICAgICAgY29uc3Qgcm93ID0gcmVzdWx0c1tpXTtcclxuICAgICAgICBjb25zdCBhcnRpY2xlcyA9IGF3YWl0IHF1ZXJ5KFwiU0VMRUNUICogRlJPTSBgaHMtYXJ0aWNsZXNgIFdIRVJFIGlkaG90c2VhcmNoID0gP1wiLFtyb3cuaWRdKVxyXG4gICAgICAgIHJlc3VsdHNbaV0uYXJ0aWNsZXMgPSBhcnRpY2xlcztcclxuICAgIH1cclxuICAgIHJlcy5zdGF0dXMoMjAwKS5qc29uKHtkYXRhOnJlc3VsdHN9KTtcclxuICAgIFxyXG59IiwidmFyIG15c3FsID0gcmVxdWlyZShcIm15c3FsXCIpO1xyXG5cclxuLy8gdmFyIHBvb2wgPSBteXNxbC5jcmVhdGVQb29sKHtcclxuLy8gXHRjb25uZWN0aW9uTGltaXQ6IDEwLFxyXG4vLyBcdGhvc3Q6IFwibG9jYWxob3N0XCIsXHJcbi8vIFx0dXNlcjogXCJyb290XCIsXHJcbi8vIFx0cGFzc3dvcmQ6IFwiXCIsXHJcbi8vIFx0ZGF0YWJhc2U6IFwiaHNkYlwiLFxyXG4vLyB9KTtcclxudmFyIHBvb2wgPSBteXNxbC5jcmVhdGVQb29sKHtcclxuXHRjb25uZWN0aW9uTGltaXQ6IDEwLFxyXG5cdGhvc3Q6IFwibG9jYWxob3N0XCIsXHJcblx0dXNlcjogXCJrYnBxdmV5cV9raG9pXCIsXHJcblx0cGFzc3dvcmQ6IFwia2JwcXZleXFfa2hvaTIwMDBcIixcclxuXHRkYXRhYmFzZTogXCJrYnBxdmV5cV9oc2RiXCIsXHJcbn0pO1xyXG5cclxuXHJcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24oc3FsLCBhcnIpIHtcclxuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG5cdFx0cG9vbC5nZXRDb25uZWN0aW9uKChlcnIsY29ubmVjdGlvbikgPT4ge1xyXG5cdFx0XHRpZihlcnIpIHJldHVybiByZWplY3QoZXJyKTtcclxuXHRcdFx0Y29ubmVjdGlvbi5xdWVyeShzcWwsIGFyciwgZnVuY3Rpb24gKGVyciwgcmVzdWx0cykge1xyXG5cdFx0XHRcdGNvbm5lY3Rpb24ucmVsZWFzZSgpO1xyXG5cdFx0XHRcdGlmIChlcnIpIHJldHVybiByZWplY3QoZXJyKTtcclxuXHRcdFx0XHRlbHNlIHJldHVybiByZXNvbHZlKHJlc3VsdHMpO1xyXG5cdFx0XHR9KTtcclxuXHRcdH0pXHJcblx0XHRcclxuXHR9KTtcclxufSIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm15c3FsXCIpOyJdLCJzb3VyY2VSb290IjoiIn0=