// module.exports = {
//     basePath: '/server'
// }